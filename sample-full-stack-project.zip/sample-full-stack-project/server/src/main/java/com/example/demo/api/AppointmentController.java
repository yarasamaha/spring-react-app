package com.example.demo.api;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;
import com.example.demo.service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.List;

@CrossOrigin("*")
@RestController
public class AppointmentController {

    @Autowired
    AppointmentService appointmentService;

    @Autowired
    public AppointmentController(AppointmentService appointmentService) {
        this.appointmentService = appointmentService;
    }

    @GetMapping(path = "/appointment/{id}")
    public Appointment getAppointment(@PathVariable("id") int id) {
        return (Appointment) appointmentService.getAppointment(id)
                .orElse(null);
    }

    @PostMapping("update-patient-appointment")
    public void updateAppointmentsGivenPatient(Patient patient){
         appointmentService.updateAppointmentsGivenPatient(patient.getId(), patient.getFirstName(), patient.getLastName());
    }

    @GetMapping("get-today-appointment")
    public List<Appointment> getTodayAppointments(){
        LocalDate date = java.time.LocalDate.now();
        return appointmentService.getTodayAppointments(date.toString());
    }

    //done and tested
    @PostMapping("add-appointment")
    public Appointment addNewAppointment(@RequestBody Appointment appointment) {
        return appointmentService.addNewAppointment(appointment);
    }

    @PostMapping("update-appointment")
    public Appointment updateOldAppointment(@RequestBody Appointment appointment) {
        return appointmentService.updateOldAppointment(appointment);
    }

    @GetMapping("appointments")
    public List<Appointment> getAllAppointments() {
        return appointmentService.getAllAppointments();
    }

    @PostMapping("delete-appointment")
    public void deleteAppointmentById(int id) {
        appointmentService.deleteAppointmentById(id);
    }
}


