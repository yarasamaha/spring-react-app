package com.example.demo.api;
import com.example.demo.model.Patient;
import com.example.demo.service.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Locale;

@CrossOrigin("*")
@RestController
public class PatientController {

    @Autowired
    PatientService patientService;

    @Autowired
    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    //required
    @GetMapping(path = "/patient/{id}")
    public Patient getPatient(@PathVariable("id") int id) {
        return (Patient) patientService.findPatientById(id)
                .orElse(null);
    }

    //required
    @PostMapping("add-patient")
    public Patient saveNewPatient(@RequestBody Patient patient) {
        return patientService.savePatient(patient);
    }

    @PostMapping("update-old-patient")
    public void updateOldPatient (Patient patient){
        patientService.updateOldPatient(patient.getId(), patient.getFirstName(), patient.getLastName());
    }

    //required
    @GetMapping("search-patient")
    public List<Patient> searchPatient(@RequestBody String searchTerm) {
        return patientService.searchPatient(searchTerm);
    }

    //not required
    @GetMapping("patients")
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }

    //not required
    @PostMapping("delete-patient")
    public void deleteById(int id) {
        patientService.deletePatientById(id);
    }



        }


