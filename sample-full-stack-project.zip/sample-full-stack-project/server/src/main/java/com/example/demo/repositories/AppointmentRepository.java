package com.example.demo.repositories;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, Integer> {

    @Query(value = "SELECT a FROM Appointment a WHERE a.appointmentDate = :date AND a.canceled = 'false'" +
            " AND a.done = 'false'")
    List<Appointment> getTodayAppointments(@Param("date") String date);

    @Modifying
    @Transactional
    @Query("Update Patient p set p.firstName = :firstName, p.lastName = :lastName WHERE p.id = :id")
    void updateAppointmentsGivenPatient(@Param("id") int id, @Param("firstName") String firstName, @Param("lastName") String lastName);
}
