package com.example.demo.service;

import com.example.demo.repositories.AppointmentRepository;
import com.example.demo.repositories.PatientRepository;
import com.example.demo.model.Patient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PatientServiceImpl implements PatientService {

    PatientRepository patientRepository;
    AppointmentRepository appointmentRepository;

    @Autowired
    public PatientServiceImpl(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    @Override
    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    public void updateOldPatient(int id, String firstName, String lastName) {
        patientRepository.updateOldPatient(id, firstName, lastName);
    }


    @Override
    public Optional<Patient> findPatientById(int id) {
        return patientRepository.findById(id);
    }

    @Override
    public List<Patient> searchPatient(String searchTerm) {
        searchTerm = searchTerm.toLowerCase();
        System.out.println("hereeeeeee"+ patientRepository.searchPatient(searchTerm)    );
        return patientRepository.searchPatient(searchTerm);
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }

    @Override
    public void deletePatientById(int id) {
        patientRepository.deleteById(id);
    }
}