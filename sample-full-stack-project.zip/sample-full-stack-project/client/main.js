const appointmentsSection = document.querySelector('.appointments-section');
const addAppointmentsSection = document.querySelector(
  '.add-appointment-section'
);
const addPatientsSection = document.querySelector('.add-patient-section');

const addAppointmentButton = document.querySelector('.add-appointment');
const addPatientButton = document.querySelector('.add-patient');
const searchInput = document.querySelector('.search-input');
const selectInput = document.querySelector('.select-patient');
const searchResults = document.querySelector('.search-results');
const selectResults = document.querySelector('.select-results');

const firstNameInput = document.querySelector('.first-name-input');
const lastNameInput = document.querySelector('.last-name-input');
const genderInput = document.querySelector('.gender-input');

const firstNameDisplay = document.querySelector('.first-name-d');
const lastNameDisplay = document.querySelector('.last-name-d');

let searchTerm = '';
let selectTerm = '';
let selectedPatientId = -1;
let selectedPatient = null;

function handleAddAppointment() {
  addAppointmentsSection.classList.remove('hidden');
  if (selectedPatient) {
    firstNameDisplay.value = selectedPatient.firstName;
    lastNameDisplay.value = selectedPatient.lastName;
  }
  refresh();
}

function handleAddPatient() {
  if (selectedPatientId > 0) {
    selectedPatient = getPatient(selectedPatientId);
    firstNameInput.value = selectedPatient.firstName;
    lastNameInput.value = selectedPatient.lastName;
    genderInput.value = selectedPatient.gender;
  } else {
    firstNameInput.value = '';
    lastNameInput.value = '';
    genderInput.value = 'male';
  }
  addPatientsSection.classList.remove('hidden');
}

function handleDoneClicked(id) {
  const appointment = getAppointment(id);
  appointment.done = true;
  updateOldAppointment(appointment);
  refresh();
}

function handleCancelClicked(id) {
  const appointment = getAppointment(id);
  appointment.canceld = true;
  updateOldAppointment(appointment);
  refresh();
}

function handlePatientClicked(patientId) {
  searchResults.classList.add('hidden');
  selectedPatientId = patientId;
  handleAddPatient();
}

function handleEditClicked(id) {
  console.log(`Edit clicked for appointment ${id}`);
}

function handleSearchTermChanged() {
  if (searchInput.value !== searchTerm) {
    searchTerm = searchInput.value;
    if (searchTerm !== '') {
      searchResults.innerHTML = getSearchResults();
    }
  }
}

function isValidPatient(p) {
  return (
    p &&
    p.firstName &&
    p.lastName &&
    p.gender &&
    p.firstName !== '' &&
    p.lastName !== ''
  );
}

function handleCancelPatient() {
  addPatientsSection.classList.add('hidden');
  selectedPatientId = -1;
  selectedPatient = null;
  firstNameInput.value = '';
  lastNameInput.value = '';
  genderInput.value = 'male';
  refresh();
}

function handleSavePatient() {
  if (selectedPatientId === -1) {
    selectedPatient = {};
  }

  selectedPatient.firstName = firstNameInput.value;
  selectedPatient.lastName = lastNameInput.value;
  selectedPatient.gender = genderInput.value;

  if (isValidPatient(selectedPatient)) {
    if (selectedPatient.id) {
      updateOldPatient(selectedPatient);
    } else {
      saveNewPatient(selectedPatient);
    }
    addPatientsSection.classList.add('hidden');
    handleAddAppointment();
  }
  selectedPatientId = -1;
  selectedPatient = null;
}

function handleSelectPatient() {
  if (selectInput.value !== selectTerm) {
    selectTerm = selectInput.value;
    if (selectTerm !== '') {
      selectResults.innerHTML = getSelectResults();
    }
  }
}

function handlePatientSelected(id) {
  selectedPatientId = id;
  selectedPatient = getPatient(id);
  console.log(selectedPatient);
  selectResults.innerHTML = '';
  selectResults.classList.add('hidden');
}

function getAppointmentCard(appointment) {
  const { appointmentTime, firstName, lastName, description, id, patientId } =
    appointment;
  return `
    <div id="${id}" class="card">
        <div class="card-header">
            ${appointmentTime}
        </div>
        <div class="card-body">
            <h5 class="card-title">${firstName} ${lastName}</h5>
            <p class="card-text">${description ? description : ''}</p>
            <div class="button-group">
                <button class="btn btn-danger" onclick="handleCancelClicked(${id})">Cancel</button>
                <button class="btn btn-success" onclick="handleDoneClicked(${id})">Done</button>
                <button class="btn btn-warning" onclick="handleEditClicked(${id})">Edit</button>
                <button class="btn btn-secondary" onclick="handlePatientClicked(${patientId})">Patient</button>
            </div>
        </div>
    </div>`;
}

function getSearchResult(patient) {
  const { id, firstName, lastName } = patient;
  return `<button class="btn btn-secondary" onclick="handlePatientClicked(${id})">${firstName} ${lastName}</button>`;
}

function getSearchResults() {
  if (searchTerm.length >= 3) {
    const results = searchPatient(searchTerm);
    if (results && results.length > 0) {
      let searchResult = '';
      for (let result of results) {
        searchResult += getSearchResult(result);
      }
      searchResults.classList.remove('hidden');
      return searchResult;
    }
  }

  searchResults.classList.add('hidden');
  return '';
}

function getSelectResult(patient) {
  const { id, firstName, lastName } = patient;
  return `<button class="btn btn-secondary" onclick="handlePatientSelected(${id})">${firstName} ${lastName}</button>`;
}

function getSelectResults() {
  if (selectTerm.length >= 3) {
    const results = searchPatient(selectTerm);
    if (results && results.length > 0) {
      let selectResult = '';
      for (let result of results) {
        selectResult += getSelectResult(result);
      }
      selectResults.classList.remove('hidden');
      return selectResult;
    }
  }

  searchResults.classList.add('hidden');
  return '';
}

function refresh() {
  const appointmentData = getTodayAppointments();
  appointmentsSection.innerHTML = '';
  for (let i = 0; i < appointmentData.length; i++) {
    const appointment = appointmentData[i];
    appointmentsSection.innerHTML += getAppointmentCard(appointment);
  }
}

window.onload = refresh;
