package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface AppointmentService {

    Appointment addNewAppointment(Appointment appointment);
    Appointment updateOldAppointment(Appointment appointment);
    Optional<Appointment> getAppointment(int id);
    void updateAppointmentsGivenPatient(int id, String firstName, String lastName);
    List<Appointment> getTodayAppointments(String date);
    List<Appointment> getAllAppointments();
    void deleteAppointmentById(int id);
}
