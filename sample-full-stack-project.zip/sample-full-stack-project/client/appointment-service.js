const today = new Date();
const tomorrow = new Date(today);
tomorrow.setDate(today.getDate() + 1);

const yesterday = new Date(today);
yesterday.setDate(today.getDate() - 1);

// let fakeAppointments = [
//     { appointmentDate: yesterday, appointmentTime: '07:00 PM', firstName: 'Ahmed', lastName: 'Karim', description: 'Back pain', patientId: 20, id: 9, canceld: false, done: false },
//     { appointmentDate: today, appointmentTime: '07:00 PM', firstName: 'Ahmed', lastName: 'Karim', description: 'Back pain', patientId: 20, id: 10, canceld: false, done: false },
//     { appointmentDate: today, appointmentTime: '07:30 PM', firstName: 'Mohamed', lastName: 'Saad', description: 'Knee pain', patientId: 21, id: 11, canceld: false, done: false },
//     { appointmentDate: today, appointmentTime: '08:00 PM', firstName: 'Karim', lastName: 'Farid', description: 'Broken arm', patientId: 22, id: 12, canceld: false, done: false },
//     { appointmentDate: tomorrow, appointmentTime: '08:00 PM', firstName: 'Karim', lastName: 'Farid', description: 'Broken arm', patientId: 22, id: 13, canceld: false, done: false },
// ];

/**
 * Initialize local state from backend
 */
let fakeAppointments = [];
fetch(`http://localhost:8080/appointments/`, { method: 'GET' })
  .then((response) => response.json())
  .then((appointments) => {
    console.log('Appointments from the backend', appointments);
    //console.log(new Date(appointments[0].appointmentDate));
    fakeAppointments = appointments.map((a) => ({
      ...a,
      appointmentDate: new Date(a.appointmentDate).getDate(),
    }));
    window.onload();
  });

// TODO Replace fake implementation with actual call to the backend
function getTodayAppointments() {
  var requestOptions = {
    method: 'GET',
    redirect: 'follow',
  };

  return fetch('http://localhost:8080/appointments/today', requestOptions)
    .then((response) => response.json())
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function getAppointment(id) {
  var requestOptions = {
    method: 'GET',
  };

  return fetch(`http://localhost:8080/appointments/${id}`, requestOptions)
    .then((response) => response.json())
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function addNewAppointment(appointment) {
  // const newId = fakeAppointments.map(p => p.id).max() + 1;
  // appointment.id = newId;

  var myHeaders = new Headers();
  myHeaders.append('Content-Type', 'application/json');
  var raw = JSON.stringify(appointment);
  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
  };
  fetch('http://localhost:8080/api/appointments', requestOptions)
    .then((response) => response.json())
    .then((result) => fakeAppointments.push(result))
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function updateOldAppointment(appointment) {
  // Optmisitc update
  const index = fakeAppointments.map((a) => a.id).indexOf(appointment.id);
  fakeAppointments[index] = appointment;

  var myHeaders = new Headers();
  myHeaders.append('Content-Type', 'application/json');
  var raw = JSON.stringify(appointment);
  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
  };
  fetch('http://localhost:8080/appointments', requestOptions)
    .then((response) => response.json())
    .then((result) => console.log(result))
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function updateAppointmentsGivenPatient(patient) {
  /**
   * Nothing needed to be done here
   */
  for (a of fakeAppointments) {
    if (a.patientId === patient.id) {
      a.firstName = patient.firstName;
      a.lastName = patient.lastName;
    }
  }
}
