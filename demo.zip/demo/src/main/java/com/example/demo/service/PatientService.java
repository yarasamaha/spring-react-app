package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;

import java.util.List;
import java.util.Optional;

public interface PatientService {

    Patient savePatient(Patient patient);  //required
    void updateOldPatient (int id, String firstName, String lastName);  //required
    Optional<Patient> findPatientById(int id);      //required
    List<Patient> searchPatient(String searchTerm); //required
    void deletePatientById(int id);
    List<Patient> getAllPatients();
}