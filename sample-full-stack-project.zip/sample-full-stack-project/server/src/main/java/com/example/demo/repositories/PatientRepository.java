package com.example.demo.repositories;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;
import java.util.Optional;

@Transactional
@Repository
public interface PatientRepository extends JpaRepository<Patient, Integer> {


    @Query("SELECT p FROM Patient as p WHERE " +
            "LOWER(p.firstName) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(p.lastName) LIKE LOWER(CONCAT('%', :searchTerm, '%'))"
    )
    List<Patient> searchPatient(@Param("searchTerm") String searchTerm);


    @Modifying
    @Transactional
    @Query("Update Patient p set p.firstName = :firstName, p.lastName = :lastName WHERE p.id = :id")
    void updateOldPatient(@Param("id") int id, @Param("firstName") String firstName, @Param("lastName") String lastName);
}

