// let fakePatients = [
//     {
//         id: 20, firstName: 'Ahmed', lastName: 'Karim', gender: 'male'
//     },
//     {
//         id: 21, firstName: 'Mohamed', lastName: 'Saad', gender: 'male'
//     },
//     {
//         id: 22, firstName: 'Karim', lastName: 'Farid', gender: 'male'
//     },
//     {
//         id: 23, firstName: 'Mary', lastName: 'Shelly', gender: 'female'
//     },
//     {
//         id: 24, firstName: 'Karim', lastName: 'Karim', gender: 'male'
//     },
//     {
//         id: 25, firstName: 'Mary', lastName: 'Karim', gender: 'female'
//     },
//     {
//         id: 26, firstName: 'Asmaa', lastName: 'Karim', gender: 'female'
//     },
// ];

// Initializing Patients from the backend
let fakePatients = [];
fetch(`http://localhost:8080/patients/`, { method: 'GET' })
  .then((response) => response.json())
  .then((patients) => {
    console.log('Patients from the backend', patients);
    fakePatients = patients;
    window.onload();
  });

// TODO Replace fake implementation with actual call to the backend
function searchPatient(searchTerm) {
  return fetch(`http://localhost:8080/api/patients/search/${searchTerm}`, {
    method: 'GET',
  })
    .then((response) => response.json())
    .then((res) => {
      console.log('Search results:', res);
      return res;
    });
  // return fakePatients.filter(p => {
  //     return p.firstName.toLowerCase().includes(searchTerm.toLowerCase()) || p.lastName.toLowerCase().includes(searchTerm.toLowerCase());
  // });
}

// TODO Replace fake implementation with actual call to the backend
function getPatient(id) {
  return fetch(`http://localhost:8080/patient/${id}`, { method: 'GET' })
    .then((response) => response.json())
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function saveNewPatient(patient) {
  var myHeaders = new Headers();
  myHeaders.append('Content-Type', 'application/json');

  var raw = JSON.stringify(patient);

  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
  };

  fetch('http://localhost:8080/patients', requestOptions)
    .then((response) => response.json())
    .then((result) => console.log(result))
    .catch((error) => console.log('error', error));
}

// TODO Replace fake implementation with actual call to the backend
function updateOldPatient(patient) {
  // Let it optimistically update
  const index = fakePatients.map((p) => p.id).indexOf(patient.id);
  fakePatients[index] = patient;
  updateAppointmentsGivenPatient(patient);

  // Update the backend
  var myHeaders = new Headers();
  myHeaders.append('Content-Type', 'application/json');
  var raw = JSON.stringify(patient);
  var requestOptions = {
    method: 'POST',
    headers: myHeaders,
    body: raw,
    redirect: 'follow',
  };

  fetch(`http://localhost:8080/patients`, requestOptions)
    .then((response) => response.text())
    .then((result) => console.log(result))
    .catch((error) => console.log('error', error));
}
