package com.example.demo.service;

import com.example.demo.model.Appointment;
import com.example.demo.model.Patient;
import com.example.demo.repositories.AppointmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class AppointmentServiceImpl implements AppointmentService{

    @Autowired
    AppointmentRepository appointmentRepository;

    @Autowired
    public AppointmentServiceImpl(AppointmentRepository appointmentRepository) {
        this.appointmentRepository = appointmentRepository;
    }

    @Override
    public Appointment addNewAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    @Override
    public Appointment updateOldAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    @Override
    public Optional<Appointment> getAppointment(int id) {
        return appointmentRepository.findById(id);
    }

    @Override
    public void updateAppointmentsGivenPatient(int id, String firstName, String lastName) {
        appointmentRepository.updateAppointmentsGivenPatient(id, firstName, lastName);
    }

    @Override
    public List<Appointment> getTodayAppointments(String date) {
        return appointmentRepository.getTodayAppointments(date);
    }


    @Override
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    @Override
    public void deleteAppointmentById(int id) {
        appointmentRepository.deleteById(id);
    }
}