package com.example.demo.model;
import javax.persistence.*;


@Entity
@Table(name = "Appointments")
public class Appointment {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id")
    private int id;

    @Column(name = "appointment_date")
    private String appointmentDate;

    @Column(name = "appointment_time")
    private String appointmentTime;

    @Column(name = "first_name")
    private String firstName;

    @Column(name = "last_name")
    private String lastName;

    @Column(name = "appointment_description")
    private String appointmentDescription;

    @Column(name = "patient_id")
    private int PatientId;

    @Column(name = "canceled")
    private boolean canceled;

    @Column(name = "done")
    private boolean done;


    public Appointment(String appointmentDate, String firstName, String lastName, String appointmentDescription) {
        this.appointmentDate = appointmentDate;
        this.firstName = firstName;
        this.lastName = lastName;
        this.appointmentDescription = appointmentDescription;
    }

    public Appointment() {
    }

    public int getId() {
        return id;
    }

    public String getAppointmentDate() {
        return appointmentDate;
    }

    public String getAppointmentTime() {
        return appointmentTime;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getAppointmentDescription() {
        return appointmentDescription;
    }

    public int getPatientId() {
        return PatientId;
    }

    public boolean isCanceled() {
        return canceled;
    }

    public boolean getDone() {
        return done;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAppointmentDate(String appointmentDate) {
        this.appointmentDate = appointmentDate;
    }

    public void setAppointmentTime(String appointmentTime) {
        this.appointmentTime = appointmentTime;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAppointmentDescription(String appointmentDescription) {
        this.appointmentDescription = appointmentDescription;
    }

    public void setPatientId(int patientId) {
        PatientId = patientId;
    }

    public void setCanceled(boolean canceled) {
        this.canceled = canceled;
    }

    public void setDone(boolean done) {
        this.done = done;
    }
}